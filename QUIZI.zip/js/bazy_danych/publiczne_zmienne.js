let prawidlowa;
let pierwsze;
let poprzednie=0;
let dobrykolor="#00A500";
let zlykolor="#A50000";
let calkowite=0;
let dobre=0;
let odpowiedzi;
let rozsunienta=true;

let numerPytania=1;
let numerDoPytan=new Array();
let odnosnikPytania=new Array();
let tablicaOdpowiedzi=new Array();
let sumaPunktow=0;
let moznoKlikalnoscPlus=true;
let moznoKlikalnoscMinus=false;
let nmrPojemnika;
let nmrOdpowiedzi;
let czasowa;
let godzina;
let minuta;
let sekunda;
let wyslaneOdpowiedzi=false;
let iloscDivow=1;
let iloscOdpowiedzi=3;

let dodany=0;
let zmiennaSuwaka=1;
let elementNapis='ELEMENT';

let szerokosc=0;

let odpalone;
let morzna=true;


