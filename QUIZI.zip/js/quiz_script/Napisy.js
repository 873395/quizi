let szerokosc=0;
function home()
{
       window.open("index.html",'_parent');
}

function stronaGlowna1()
{
       pojemnikNaObjasnieniaNaglowek.innerHTML='Wiele pytań, jedna odpowiedź';
       lewyPojemnikNapis.innerHTML='użytkowniku, na stronie możesz własnoręcznie ustalić listę pytań.<br>Dzięki temu będziesz mógł dostosować poziom oraz liczbe pytań do swojego wolnego czasu.'; 
}
