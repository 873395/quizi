let s_div = document.createElement('div');
s_div.id="sl_div";
s_div.innerHTML="QUIZI"
s_div.className="sl_div_anim_rew";
document.body.appendChild(s_div);